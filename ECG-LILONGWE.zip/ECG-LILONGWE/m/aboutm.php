<!DOCTYPE html>


<html lang ="en">

<head>
      <title>Lilongwe ECG</title>
	  <meta charset ="utf-8"/>
      <meta name= "viewport" content= "width=device-width, initial-scale=1.0">
	  <link rel="stylesheet" href="css/main.mobile.css" type="text/css">
	  <link rel="stylesheet" href="css/engine.css" type="text/css">
</head>

<body>
<?php include('headerm.php');?>



<section id="thing">

<h1>ABOUT ECG</h1>

<div id="pictori">
<img src="../imgs/cow.jpg"/>
<p>Enlightened Christian Gathering Church is a modern congregation of Christ–centered believers 
	celebrating God through the Prophetic, Healing and Deliverance Ministries. It is home to millions
	across the globe who seek to hear God speaking today.ECG is led by founder and leader Major Prophet
	Shepherd Bushiri.
	ECG is more than a church, it is a family, where every race and class is accommodated , where the DNA 
	of God declares each of us as citizens of heaven, lives are transformed and miracles and testimonies 
	are the order of the day as demons and challenges are confronted and conquered; in our family we don’t
	stress!.
	At ECG we are a friendly and happy family made up of people from all walks of life, and different backgrounds
	who are united through love of christ. we believe in transforming power of jesus christ and bringing down
	the kingdom of God. This power we believe changes lives, brings healing to the sick, deliverance to the
	tormented, happines and joy to the weary and frustrated. We invite you to experience this changing power 
	and love, and we promise you. <span id="same">"YOU WILL NEVER BE THE SAME"</span>
</p>

</div>




</section>

<?php include('footerm.php');?>




<script type="text/javascript" src="js/jquery-3.1.1.min.js"></script>
<script type="text/javascript" src="js/about.js"></script>
</body>

</html>

