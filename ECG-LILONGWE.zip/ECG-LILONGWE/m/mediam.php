<!DOCTYPE html>


<html lang ="en">

<head>
      <title>Lilongwe ECG</title>
	  <meta charset ="utf-8"/>
      <meta name= "viewport" content= "width=device-width, initial-scale=1.0">
	  <link rel="stylesheet" href="css/main.mobile.css" type="text/css">
	  <link rel="stylesheet" href="css/engine.css" type="text/css"> 
</head>

<body>
<?php include('headerm.php');?>

<div id="thum-hod">

      <div class="zuma" id="zuma1">
	     <img src="../imgs/1.jpg"/>
	  </div>
	  
	  <div class="zuma"  id="zuma2">
	     <img src="../imgs/2.jpg"/>
	  </div>
	  
	  <div class="zuma" id="zuma3" >
	      <img src="../imgs/3.jpg"/>
	  </div>
	  
	  <div class="zuma" id="zuma4" >
	     <img src="../imgs/4.png"/>
	  </div>
	  
	  <div class="zuma"  id="zuma5">
	     <img src="../imgs/5.png"/>
	  </div>
	  
	  <div class="zuma" id="zuma6">
	      <img src="../imgs/6.png"/>
	  </div>
	  
	  <div class="zuma" id="zuma7">
	     <img src="../imgs/7.png"/>
	  </div>
	  
	  <div class="zuma" id="zuma8">
	     <img src="../imgs/8.png"/>
	  </div>
	  
	  <div class="zuma" id="zuma9">
	      <img src="../imgs/9.jpg"/>
	  </div>
	  
	  <div class="zuma" id="zuma10">
	     <img src="../imgs/10.jpg"/>
	  </div>
	  
	  <div class="zuma" id="zuma11">
	     <img src="../imgs/11.png"/>
	  </div>
	  
	  <div class="zuma" id="zuma12">
	      <img src="../imgs/12.jpg"/>
	  </div>
	  
	
</div>

<div id="clean"></div>

<?php include('footerm.php');?>








<script type="text/javascript" src="../js/jquery-3.1.1.min.js"></script>
<script type="text/javascript" src="../js/gallery.js"></script>
</body>

</html>