<!DOCTYPE html>


<html lang ="en">

<head>
      <title>Lilongwe ECG</title>
	  <meta charset ="utf-8"/>
      <meta name= "viewport" content= "width=device-width, initial-scale=1.0">
	  <link rel="stylesheet" href="css/main.mobile.css" type="text/css">
	  <link rel="stylesheet" href="css/engine.css" type="text/css">  
</head>

<body>


<header>
		<nav>
		  
			<img id="logoecg" src="../imgs/logo.png"/>
		  

			<div class="menu-btn">
				<div class="menu-btn-block top"></div>
				<div class="menu-btn-block middle"></div>
				<div class="menu-btn-block bottom"></div>
			</div>

			<ul>
			    <li><a href="indexm.php">HOME</a></li>
				<li><a href="aboutm.php">ABOUT</a></li>
				<li><a href="mediam.php">MEDIA</a></li>
				<li><a href="programsm.php">PROGRAMS</a></li>
				<li><a href="sermonsm.php">SERMONS</a></li>
				<li><a href="eventsm.php">EVENTS</a></li>
				<li><a href="contactsm.php">CONTACTS</a></li>
			</ul>
		</nav>
</header>

 <script type="text/javascript" src="../js/jquery-3.1.1.min.js"></script>
 <script type="text/javascript" src="js/main.mobile.js"></script>
 <script type="text/javascript">
 

//a link event handler
$('header nav ul li a').click(function() {
        $('.menu-btn:visible').click();
    });

//menu-btn event handler
(function(){
	 
	 var menuBtn = $('div.menu-btn'),
         menuBtnBlock = menuBtn.find('div.menu-btn-block');
		 
	 var slide = $("#slider"); 	 
	 var unlist = $("header nav ul"); 
	 var pager = $(".pager"); 
	 
	 menuBtn.on('click', function() { 
	      unlist.toggleClass("open");
		  /*slide.fadeToggle(500);
		  pager.fadeToggle(500);*/
		  menuBtnBlock.toggleClass('activ'); 
	 });
	 
	 
 })();

 
 
 
 </script>

</body>



</html>