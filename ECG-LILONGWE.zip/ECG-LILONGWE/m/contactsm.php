<!DOCTYPE html>


<html lang ="en">

<head>
   <title>Lilongwe ECG</title>
	  <meta charset ="utf-8"/>
      <meta name= "viewport" content= "width=device-width, initial-scale=1.0">
	  <link rel="stylesheet" href="css/main.mobile.css" type="text/css">
	  <link rel="stylesheet" href="css/engine.css" type="text/css">
</head>

<body>
<?php include 'headerm.php';?>
<section id="chikeeper">
<div id="musu">
 <h1>CONTACT US</h1>
</div>
<div id="sorte">
  <div class="sof">
    <h2>ECG CITY</h2>
	<p>Area 47,Off Mchinji Road 
		from Petroda filling station 
		Next to Anglican Theological College
		opposite Dreamland
	</p>
  </div>
  <div class="sof mko">
     <img id="call" src="../imgs/man1.png"/>
	 <p id="phonn">0888 963 220<br> 0994 860 773</p>
	 <img id="callt" src="../imgs/en1.png"/>
	 <p id="ema">Ecglilongwe@gmail.com</p>
  </div>

</div>

<div id="map">
 <img src="../imgs/map.png"/>

</div>




</section>

<?php include 'footerm.php';?>


<script type="text/javascript" src="../js/jquery-3.1.1.min.js"></script>
<script type="text/javascript" src="../js/programs.js"></script>
</body>

</html>
