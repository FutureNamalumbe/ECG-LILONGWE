<!DOCTYPE html>


<html lang ="en">

<head>
      <title>Lilongwe ECG</title>
	  <meta charset ="utf-8"/>
	  <link rel ="stylesheet" href="css/main.mobile.css" type="text/css"/>  
	  <link rel ="stylesheet" href="css/engine.css" type="text/css"/> 
      <meta name= "viewport" content= "width=device-width, initial-scale=1.0">

</head>

<body>

<?php include 'headerm.php';?>

<h1 id="up-head">UPCOMING EVENTS</h1>



<div id="eve-cont">
  <h2>WOMEN'S CONFERENCE</h2>
<img src="../imgs/mary.jpg"/>
<p id="sep">9 September 2017</P>
<p>EXEMIA LODGE</P>


</div>

<?php include 'footerm.php';?>


</body>

</html>

