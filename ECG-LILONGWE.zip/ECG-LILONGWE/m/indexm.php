<!DOCTYPE html>


<html lang ="en">

<head>
      <title>Lilongwe ECG</title>
	  <meta charset ="utf-8"/>
      <meta name= "viewport" content= "width=device-width, initial-scale=1.0">
	  <link rel="stylesheet" href="css/main.mobile.css" type="text/css">
	  <link rel="stylesheet" href="css/engine.css" type="text/css">  
</head>

<body>


<?php include('headerm.php');?>


<section id="hero">
<h1>WELCOME TO<br>ENLIGHTENED CHRISTIAN GATHERING <br>LILONGWE CHURCH </h1>


</section>



<section id="desc">
		<div class="desc-inner-div">
		     <div class="medo">
						 <img src="../imgs/church.png"/>
			 </div>
			<h2>Who we are</h2>
			<p id="faiza">Enlightened Christian Gathering, Is a place of Liberty. We stand together as one, Believing in our Lord</p>
		 
		</div>

		<div class="desc-inner-div">
		    <div class="medo">
						 <img src="../imgs/like.png"/>
			 </div>
			<h2>Our Beliefs</h2>
			<p id="faiza2">We believe that Jesus died, And he rose up from the dead, Seated at the right hand of the father for generations to come.</p>
		</div>

		<div class="desc-inner-div">
		    <div class="medo">
						 <img src="../imgs/power.png"/>
		   </div>
			<h2>Our Mission</h2>
			<p>To bear witness for Christ and his truth and to spread the gospel of the kingdom in all its fullness and Power.</p>
		</div>

		<div class="desc-inner-div">
		    <div class="medo">
						 <img src="../imgs/ran.png"/>
		   </div>
			<h2>Location</h2>
			<p>Area 47,Off Mchinji Road from Petroda filling station Next to Anglican Theological College opposite Dreamland</p>
		</div>
</section>

<section id="year-theme">

  <div id="spiral">
		<img src="../imgs/spi3.jpg"/>
  </div>
  
   
  <div id="honeybox">
	 <img src="../imgs/hon3.png"/>
  </div> 
  
  <div id="spiral2">
	<img src="../imgs/spik.jpg"/>
  </div>
  
	<img id="waf" src="../imgs/waf.jpg"/>

   

</section>

<section id="ne-sch-ev">

 <div id="church-p">
   <h2>Church programs</h2>
   <h3>Sunday Service</h3>
   <p>Sunday service starts at 8:00AM</p>
   <h3>MOPRA</h3>
   <p>Morning prayers commence every morning, from 6:00AM - 7:00AM</p>
   <h3>HOMECELL</h3>
   <p>Church Members meet in their respective homecells every tuesday 6:00PM</p>
   <h3>HOUSE OF FIRE</h3>
   <p>A time of prayer intecessions,scheduled at 6:00PM wednesday</p>
   <h3>MID-WEEK SERVICE</h3>
   <p>Another power packed service on thursday at 6:00PM</p>
 </div>
 

</section>

<section id="form">


<div id="clear"></div>
 <div id="contact-us"><h2>CONTACT US</h2>
 </div>
      <div id="contact-us-div-form">
		 
	<form id="my_form">
      <fieldset>
		 <label for="first_name">first name<br></label><input type="text" id="fn" required><br/>
		 <label for="last_name">last name<br></label><input type="text" id="ln" required><br/>
		 <label for="email">Email address<br></label><input type="email" id="e" required><br/>
		 <label for="phone">Phone number<br></label><input type="text" id="p" required><br/>
      </fieldset>
	     <label for="message">Message<br></label><input type="text" name="message" id="m"><br/>
       <p><input id="mybtn" type="submit" value="Submit Form"> <span id="status"></span></p>
    </form>		 
	</div>
</section>



<?php include 'footerm.php';?>


 <script type="text/javascript" src="../js/jquery-3.1.1.min.js"></script>
 <script type="text/javascript" src="js/main.mobile.js"></script>

</body>



</html>