<!DOCTYPE html>


<html lang ="en">

<head>
      <title>Lilongwe ECG</title>
	  <meta charset ="utf-8"/>
	  <link rel ="stylesheet" href="css/main.css" type="text/css"/>  
	  <link rel ="stylesheet" href="css/media-query.css" type="text/css"/> 
          <meta name= "viewport" content= "width=device-width, initial-scale=1.0">
	  <link rel="stylesheet" href="font-awesomen/css/font-awesome.min.css" type="text/css">
          <link href="http://webtester.acoxi.com/widgets/fblikebox.css" rel="stylesheet">
	   <script type="text/javascript">
	     if(screen.width <= 699){
			document.location = "m/indexm.php";
		 }	
       </script>
	   <style>
	   width: 100% !important;
	   
	   </style>
</head>

<body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.10";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<?php include 'header.php';?>



    
<section id="hero">

<?php include 'video.php';?>
<h1>WELCOME TO<br>ENLIGHTENED CHRISTIAN GATHERING <br>LILONGWE CHURCH </h1>
<div id="overlay"></div>

</section>

<section id="desc">
		<div class="desc-inner-div">
		    <div class="medo">
						 <img src="imgs/church.png"/>
			 </div>
			<h2>Who we are</h2>
			<p id="faiza">Enlightened Christian Gathering, Is a place of Liberty. We stand together as one, Believing in our Lord</p>
		 
		</div>

		<div class="desc-inner-div">
		     <div class="medo">
						 <img src="imgs/like.png"/>
			 </div>
			<h2>Our Beliefs</h2>
			<p id="faiza2">We believe that Jesus died, And he rose up from the dead, Seated at the right hand of the father for generations to come.</p>
		</div>

		<div class="desc-inner-div">
		   <div class="medo">
						 <img src="imgs/power.png"/>
		   </div>
			<h2>Our Mission</h2>
			<p>To bear witness for Christ and his truth and to spread the gospel of the kingdom in all its fullness and Power.</p>
		</div>

		<div class="desc-inner-div">
		   <div class="medo">
						 <img src="imgs/ran.png"/>
		   </div>
		   
			<h2>Location</h2>
			<p>Area 47,Off Mchinji Road from Petroda filling station Next to Anglican Theological College opposite Dreamland</p>
		</div>
</section>

<section id="year-theme">

	
	
	<div id="waf">
	  <img src="imgs/waf.jpg"/>
	</div>
	
	
	
	
	<div id="honword">
	  <img src="imgs/honword.png"/>
	</div>
	<div id="year-of">
	  <h2>YEAR <br>OF</h2>
	</div>
	  



    <div id="spiral">
		<img src="imgs/spi3.jpg"/>
	</div>


	<div id="honeybox">
	 <img src="imgs/hon3.png"/>
	</div>
	
	
	<div id="wordup">
	<img src="imgs/spi.jpg"/>
	</div>

</section>
<div id="clear"></div>


<section id="ne-sch-ev">

   <div id="frame-wrap">
       <h2>LATEST FACEBOOK POSTS</h2>
       <input type="button" value="Prophet S.B" id="btn" />
	   <input type="button" value="Lilongwe ECG" id="btn2"/>
	   
		<div id="major-frame">
			 <div class="fb-page" data-href="https://web.facebook.com/shepherdbushiriministries/" data-tabs="timeline" data-width="500" data-height="400px" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"></div>
		</div>
		
		<div id="llz-frame">
				<div class="fb-page" data-href="https://web.facebook.com/ECGLilongwe/" data-tabs="timeline" data-width="500" data-height="400px" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"></div>
		</div>
   </div>
   
   <div id="programs">
     <div class="churchdiv">
       <h2>CHURCH PROGRAMS</h2>
	 </div>
	  <div class="wis">
	     <h3>SUNDAY SERVICE</h3>
		 <p class="pow">Sunday service starts at 8:00AM</p>
	  </div> 
	  <div class="wis">
	    <h3>MOPRA</h3>
		<p class="pow2">Morning prayers commence every morning, from 6:00AM - 7:00AM</p>
	  </div>
	  <div class="wis">
	    <h3>HOMECELL</h3>
		<p class="pow2" id="homie">Church Members meet in their respective homecells every tuesday 6:00PM</p>
	  </div>
	  <div class="wis">
	     <h3>HOUSE OF FIRE</h3>
		 <p class="pow2" id="flamezz">A time of prayer intecessions,scheduled at 6:00PM wednesday</p>
	  </div>
	  <div class="wis">
	     <h3>MID-WEEK SERVICE</h3>
		 <p class="pow2">Another power packed service on thursday at 6:00PM</p>
	  </div>
   </div>
   
   <div id="news">
     <div class="churchdiv">
       <h2>NEWS</h2>
	 </div>
	   <div class="news-article">
			 <img src="imgs/rolls.jpg"/>
			 <h4>Prophet sherpherd Bushiri shocked with wife gift of posh Rolls Royce</h4>
			 <p> ~ Nyasa times ~ </p>
	   </div>
	   <div class="news-article">
			 <img src="imgs/google.jpg"/>
			 <h4>Sherpherd Bushiri investments partners with Google</h4>
			 <p> ~ Diaspora engager ~ </p>
	   </div>
	   <div class="news-article">
			 <img src="imgs/aus.jpg"/>
			 <h4>Prophet sherpherd Bushiri shakes up Australia with Jesus Christ Gospel</h4>
			 <p> ~ Maravi Post ~ </p>
	   </div>
	   <div class="news-article">
			 <img src="imgs/ord1.jpg"/>
			 <h4>Prophet Bushiri ordains 11000 ECG leaders </h4>
			 <p> ~ Nyasa times ~ </p>
	   </div>
	 </div>
	
  
	
 
   
    
</section>





<section id="form">


<div id="clear"></div>
 <div id="contact-us"><h2>CONTACT US</h2>
 </div>
      <div id="contact-us-div-form">
		 
	<form id="my_form">
      <fieldset>
		 <label for="first_name">first name<br></label><input type="text" id="fn" required><br/>
		 <label for="last_name">last name<br></label><input type="text" id="ln" required><br/>
		 <label for="email">Email address<br></label><input type="email" id="e" required><br/>
		 <label for="phone">Phone number<br></label><input type="text" id="p" required><br/>
      </fieldset>
	     <label for="message">Message<br></label><input type="text" name="message" id="m"><br/>
       <p><input id="mybtn" type="submit" value="Submit Form"> <span id="status"></span></p>
    </form>		 
	</div>
</section>






























<section id="declarations">

<div id="paps">
<img src="imgs/paps1.jpg"/>

</div>

<h2>PROPHETIC DECLARATIONS</h2>

<div id="slider" class="cycle-slideshow"
								data-cycle-fx="scrollHorz"
								data-cycle-timeout="6500"
								data-cycle-speed="2000" 
								data-cycle-slides="> div">
								
			<p class="cycle-pager"></p>						

					   
			<div class="item"> <!--- item 1 --->
				<p>Where there is a casting down, you shall find yourself rising up. Where there is lack,
				    you shall enjoy abundance. Your case will always be different because greater is He who is
					in you than he who is in the world.
				</p>
				<p class="mjr1">~Major 1~</p>
				
			 </div> <!--- end item 1 --->
			
			<div class="item"><!--- item 2 --->
				<p>You don't have to go after the blessing, go after God. Honour Him with your life and the blessings
				will follow.
				</p>
				<p class="mjr1">~Major 1~</p>
			</div><!--- end item 2 --->
			
			<div class="item"><!--- item 3 --->
				<p>The same storm that was sent by the enemy to break you, is going to be the storm that God
				uses to make you into a champion.
				</p>
				<p class="mjr1">~Major 1~</p>
			</div><!--- end item 3 --->
			    
			<div class="item"> <!--- item 4 --->
				<p>Grace can buy the whole world.
				</p>	
              <p class="mjr1">~Major 1~</p>				
			</div><!---end item 4 --->		

		
								
								
</div> 							
								
								
								
								
								

</section>
<div id="clear"></div>


<?php include 'footer.php';?>
    <script type="text/javascript" src="js/jquery-3.1.1.min.js"></script>
	<script type="text/javascript" src="js/main.js"></script>
	<script type="text/javascript" src="js/jquery.cycle2.min.js"></script> 
    <script type="text/javascript" src="js/jquery.cycle2.flip.min.js"></script>
	<script type="text/javascript" src="js/mail.js"></script>
</body>



</html>