<!DOCTYPE html>


<html lang ="en">

<head>
      <title>Lilongwe ECG</title>
	  <meta charset ="utf-8"/>
	  <link rel ="stylesheet" href="css/animate.css" type="text/css"/>  
	  <link rel ="stylesheet" href="css/main.css" type="text/css"/>  
	  <link rel ="stylesheet" href="css/media-query.css" type="text/css"/> 
      <meta name= "viewport" content= "width=device-width, initial-scale=1.0">
	  <script type="text/javascript">
	     if(screen.width <= 699){
			document.location = "m/programs.php";
		 }	
       </script>
<style>


</style>
</head>

<body>
<div class="background-wrap">
		  <video id="video-bg-elem" preload="auto" autoplay="true" loop="loop" muted="muted" class="vid">
			<source src="imgs/backg.mp4" type= "video/mp4">  
		  </video>
</div>
<?php include 'header2.php';?>

<h1 id="church-pheader">CHURCH PROGRAMS</h1>




<div id="sunday-program">
<h3 class="tito">Sunday Service</h3>
   <p>08:30 - 09:45am -- Intercessions</p>
   <p>10:30 - 11:00am -- First Teaching</p>
   <p>11:50 - 02:00pm -- Second Teaching</p> 
</div>




<div id="mopra-program">
<h3 class="tito">MOPRA</h3>
   <p>Morning prayers commence every morning, from 6:00AM - 7:00AM</p> 
</div>


<div id="homecell-program">
<h3 class="tito">HOMECELL</h3>
   <p>Church Members meet in their respective homecells every tuesday 6:00PM<span id="lochom">View Locations</span></p> 
   <div id="contentloc">
   Area 47,15,6,14 meet at Mkwichi secondary school<br>

   Goshen (Area 18 and kwa Saint) meet at Chatuwa Primary School.<br>
   
   Berthsaida(Area 23) meet at Mlodza Primary School<br>
   
   Doxa(Falls,Police lines,Malangalanga, Area 2,Upper Biwi, Mwaebyekondo and Technical) meet at Lilongwe LEA<br>
   
   Rhema (Area 25-A, B and C) meet at Kalambo Primary School<br>
   
   Sons and Daughters of Major(Kaliyeka) meet at Kaliyeka Primary<br>
   
   Mtsiliza and Mtandire meet at Mtsiliza Primary School<br>
   
   Mount Sinai(Gulliver) meet at Chikhoma's residence<br>
   
   Rayoni(Area 49,Dubai and Proper) meet at Lingadzi Hall<br>
   
   Joash(Nkhoma) meet at Brenda Chalandas residence<br>
   
   Cairos(Likuni, Chigwirizano and Chinsapo 1&2) meet at Kakule Primary school<br>
   
   Lumbadzi meet at Chinkhuti Primary school<br>
   
   Elshaddai (Area 36,st jones,Kaphiri, upto Road block) meet at Mrs Ngomano's residence<br>
   
   Kawale 1&2 and Mchesi meet at Elder Dzonziz residence<br>
   
   Light house(Area 10,11,12,43,44 and Kauma) meet at Elder Chalandas residence<br>
   
   Jehovah Nissi(Njewa, Chitipi and Airwing) Njewa primary school<br>
   
   Victors Assembly ( Chilinde 1&2, CCDC and Kamuzu Barracks) meet at Chiwoko Primary School<br>
    
   Shiloh (Area 22,24 and Kwa Gaga) meet at Christian<br>
   
   
   
   
   
   
   
   
   
   
   </div>
</div>



<div id="house-program">
<h3 class="tito">HOUSE OF FIRE</h3>
   <p>A time of prayer intecessions,scheduled at 6:00PM wednesday</p> 
</div>


<div id="mid-program">
<h3 class="tito">MID WEEK SERVICE</h3>
   <p>A time of prayer intecessions,scheduled at 6:00PM wednesday</p> 
</div>

<?php include 'footer.php';?>


<script type="text/javascript" src="js/jquery-3.1.1.min.js"></script>
<script type="text/javascript" src="js/programs.js"></script>
</body>

</html>
