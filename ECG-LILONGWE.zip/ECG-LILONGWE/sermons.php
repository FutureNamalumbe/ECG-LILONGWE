<!DOCTYPE html>


<html lang ="en">

<head>
      <title>Lilongwe ECG</title>
	  <meta charset ="utf-8"/>
	  <link rel ="stylesheet" href="css/main.css" type="text/css"/>  
	  <link rel ="stylesheet" href="css/media-query.css" type="text/css"/> 
      <meta name= "viewport" content= "width=device-width, initial-scale=1.0">
	     <script type="text/javascript">
	     if(screen.width <= 699){
			document.location = "m/sermonsm.php";
		 }	
       </script>

<style>	 
#aud-cont{
	border:1px solid #ff6633;
	margin:1rem 0rem 1rem 1rem;
	height:25rem;
	float:left;	
}


#aud-cont p{
	font-family:Arial;
	font-size:1.2rem;
	border-bottom:1px solid #ff6633;
	padding-bottom:1rem;
	padding-top:1rem;
	color:#666;
}




</style> 

</head>

<body>

<?php include 'header2.php';?>



<h1 id="up-head">SERMONS</h1>

<div id="aud-cont">
	<img src="imgs/shapak.png"/>
	<div>
	  <p>Jesus Christ:The mystery behind the name</p>
		<audio controls loop>
			<source src="imgs/sem.mp3" type="audio/mpeg"/>
		</audio>
	</div>
</div>
<?php include 'footer.php';?>

</body>

</html>

