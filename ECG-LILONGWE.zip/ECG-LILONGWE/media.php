<!DOCTYPE html>


<html lang ="en">

<head>
      <title>Lilongwe ECG</title>
	  <meta charset ="utf-8"/>
	  <link rel ="stylesheet" href="css/animate.css" type="text/css"/>  
	  <link rel ="stylesheet" href="css/main.css" type="text/css"/>  
	  <link rel ="stylesheet" href="css/media-query.css" type="text/css"/> 
      <meta name= "viewport" content= "width=device-width, initial-scale=1.0">
	  <script type="text/javascript">
	     if(screen.width <= 699){
			document.location = "m/mediam.php";
		 }	
       </script>
<style>





#photoga{
	float:left;
	margin:5.5rem 0px 0px 2rem;
	color:crimson;
	position:absolute;
}


#photodesco{
	float:left;
	margin:36.55rem 0px 0px 2rem;
	color:#fff;
	position:absolute;
	z-index:300000;
    background:rgba(0,0,0,0.7);
	width:45%;
	height:4rem;
	text-align:center;
}


#big-one{
	 width:45%;
     height:32rem;
     float:left;	
     background:#FF5566;
     margin: 8.6rem 0px 0px 2rem ;	   
	 position:relative;
}

#thumb-star{
	 width:50%;
     height:37rem;	
     float:right;	
     margin-top: 6rem;	 
}

.zuma{
	 width:31.8%;
     height:8.3rem;	
     float:left;
	 border:3px solid #999;
}

.zuma:hover{
	cursor:pointer; 
	border:3px solid gold;
}

.zuma img,#big-one img{
	 width:100%;
     height:100%;
}




</style>
</head>

<body>

<?php include 'header2.php';?>

<h1 id="photoga">ECG PHOTO GALLERY</h1>
<h1 id="photodesco"></h1>

<div id="clear"></div>


<div id="big-one" class="animated shake">
 <img src="imgs/8.png"/>
 
</div>
 
<div id="thumb-star">
  
	  <div class="zuma" id="zuma1">
	     <img src="imgs/1.jpg"/>
	  </div>
	  
	  <div class="zuma"  id="zuma2">
	     <img src="imgs/2.jpg"/>
	  </div>
	  
	  <div class="zuma" id="zuma3" >
	      <img src="imgs/3.jpg"/>
	  </div>
	  
	  <div class="zuma" id="zuma4" >
	     <img src="imgs/4.png"/>
	  </div>
	  
	  <div class="zuma"  id="zuma5">
	     <img src="imgs/5.png"/>
	  </div>
	  
	  <div class="zuma" id="zuma6">
	      <img src="imgs/6.png"/>
	  </div>
	  
	  <div class="zuma" id="zuma7">
	     <img src="imgs/7.png"/>
	  </div>
	  
	  <div class="zuma" id="zuma8">
	     <img src="imgs/8.png"/>
	  </div>
	  
	  <div class="zuma" id="zuma9">
	      <img src="imgs/9.jpg"/>
	  </div>
	  
	  <div class="zuma" id="zuma10">
	     <img src="imgs/10.jpg"/>
	  </div>
	  
	  <div class="zuma" id="zuma11">
	     <img src="imgs/11.png"/>
	  </div>
	  
	  <div class="zuma" id="zuma12">
	      <img src="imgs/12.jpg"/>
	  </div>
	  
	  
	 
</div>

<?php include 'footer.php';?>

<script type="text/javascript" src="js/jquery-3.1.1.min.js"></script>
<script type="text/javascript" src="js/gallery.js"></script>
</body>

</html>

