<!DOCTYPE html>


<html lang ="en">

<head>
      <title>Lilongwe ECG</title>
	  <meta charset ="utf-8"/>
	  <link rel ="stylesheet" href="css/main.css" type="text/css"/>  
	  <link rel ="stylesheet" href="css/media-query.css" type="text/css"/> 
      <meta name= "viewport" content= "width=device-width, initial-scale=1.0">
</head>

<style>

#about-info{
	width:53.3%;
	height:30rem;
	border:1px solid #000;
	float:left;
	margin-top:5rem;
	padding-left:1rem;
	background:rgba(0,0,0,0.5);
	color:#fff;
}

#about-info p{
	line-height:1.5rem;
	font-size:1.2rem;
	
}


#about-img{
	width:45.2%;
	height:30rem;
	border:1px solid #000;
	float:right;
	margin-top:5rem;
	margin-bottom:1.5rem;

}

#about-img img{
	width:100%;
	height:30rem;
}



#same{
	color:red;
	display:block;
	text-align:center;
	margin-top:1rem;
}


#back-serv{
	width:100%;
	height:43.7rem;
	background-color:#fff;
	position:fixed;
	z-index:-1;
}

#selection{
	width:100%;
	height:9rem;
	clear:both;

}

.thumb{
	width:10rem;
	height:8rem;
	border:1px solid #333;
	margin:0px 1rem;
	float:left;
	text-align:center;
	margin-bottom:3rem;
	color:#fff;
	background:rgba(0,0,0,0.5);
}

.thumb:hover{
	cursor:pointer;
}

.thumb img{
	width:100%;
	height:5rem;
}


#ecg-cont{
	margin-left:24rem;
}

#wise-cont h3{
	font-size:0.9rem;
	color:gold;
}

#major-cont h3{
	font-size:1rem;
}



</style>







<body>

<?php include 'header2.php'; ?>

<section id="back-serv">

	<div class="background-wrap">
			  <video id="video-bg-elem" preload="auto" autoplay="true" loop="loop" muted="muted" class="vid">
				<source src="imgs/bk.mp4" type= "video/mp4">  
			  </video>
	</div>
</section>

<div id="about-info">

<h1>ABOUT WISEMAN TREVOUR</h1>

 





</div>

<div id="about-img">

<img src="imgs/wise.jpg"/>


</div>

<div id="selection">

  <a href="about.php"><div class="thumb" id="ecg-cont">
      <img src="imgs/download.jpg"/>
	  <h3>ABOUT ECG</h3>
  </div></a>
  
  <a href="about.major.php"><div class="thumb" id="major-cont">
      <img src="imgs/major.jpg"/>
	  <h3>ABOUT MAJOR 1</h3>
  </div></a>
  
  <a href="about.wiseman.php"><div class="thumb" id="wise-cont">
       <img src="imgs/wise.jpg"/>
	   <h3>ABOUT WISEMAN TREVOUR</h3>
  </div></a>
  
</div>



<?php include 'footer.php'; ?>
</body>

</html>

