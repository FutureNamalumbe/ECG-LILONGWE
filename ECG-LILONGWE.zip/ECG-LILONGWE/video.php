<!DOCTYPE html>


<html lang ="en">

<head>
      <title>Lilongwe ECG</title>
	  <meta charset ="utf-8"/>
	  <link rel ="stylesheet" href="css/main.css" type="text/css"/>  
	  <link rel ="stylesheet" href="css/media-query.css" type="text/css"/> 
      <meta name= "viewport" content= "width=device-width, initial-scale=1.0">
</head>

<body>
<div class="background-wrap">
		  <video id="video-bg-elem" preload="auto" autoplay="true" loop="loop" muted="muted" class="vid">
			<source src="imgs/bakk.mp4" type= "video/mp4">  
		  </video>
</div>

</body>


</html>