<!DOCTYPE html>


<html lang ="en">

<head>
      <title>Lilongwe ECG</title>
	  <meta charset ="utf-8"/>
	  <link rel ="stylesheet" href="css/main.css" type="text/css"/>  
	  <link rel ="stylesheet" href="css/media-query.css" type="text/css"/> 
	  <link rel ="stylesheet" href="css/grid.css" type="text/css" >	
      <meta name= "viewport" content= "width=device-width, initial-scale=1.0">
	  <script type="text/javascript">
	     if(screen.width <= 699){
			document.location = "m/aboutm.php";
		 }	
       </script>
</head>





<body>

<?php include 'header2.php';?>
<section id="back-serv">

	<div class="background-wrap">
			  <video id="video-bg-elem" preload="auto" autoplay="true" loop="loop" muted="muted" class="vid">
				<source src="imgs/backg.mp4" type= "video/mp4">  
			  </video>
	</div>
</section>




<div class="grid"> <!--- grid --->
     <div class="row"><!--- row --->    


		 <div class="col-wd-8 col-md-6 col-sm-12">
		     <div id="about-info" class="col">
			 
			 <h1>ABOUT ECG</h1>
<p> Enlightened Christian Gathering Church is a modern congregation of Christ–centered believers 
	celebrating God through the Prophetic, Healing and Deliverance Ministries. It is home to millions
	across the globe who seek to hear God speaking today.ECG is led by founder and leader Major Prophet
	Shepherd Bushiri.
	ECG is more than a church, it is a family, where every race and class is accommodated , where the DNA 
	of God declares each of us as citizens of heaven, lives are transformed and miracles and testimonies 
	are the order of the day as demons and challenges are confronted and conquered; in our family we don’t
	stress!.
</p>	

<p id="wilu">
	At ECG we are a friendly and happy family made up of people from all walks of life, and different backgrounds
	who are united through love of christ. we believe in transforming power of jesus christ and bringing down
	the kingdom of God. This power we believe changes lives, brings healing to the sick, deliverance to the
	tormented, happines and joy to the weary and frustrated. We invite you to experience this changing power 
	and love, and we promise you. <span id="same">"YOU WILL NEVER BE THE SAME"</span>
</p>
			 </div>
		</div> 
		
		<div class="col-wd-4 col-md-6 col-sm-12">
		     <div id="about-img" class="col">
			    <img src="imgs/cow.jpg"/>
			 </div>
		</div>
		 
		 
 
		 
	 </div> <!--- end row --->
  </div> <!--- end grid --->







<div id="selection">

   <div class="thumb" id="ecg-cont">
      <img src="imgs/download.jpg"/>
	  <h3>ABOUT ECG</h3>
   </div>
  
  <div class="thumb" id="major-cont">
      <img src="imgs/major.jpg"/>
	  <h3>ABOUT MAJOR 1</h3>
  </div>
  
</div>



<?php include 'footer.php'; ?>

<script type="text/javascript" src="js/jquery-3.1.1.min.js"></script>
<script type="text/javascript" src="js/about.js"></script>
</body>

</html>

