<!DOCTYPE html>


<html lang ="en">

<head>
      <title>Lilongwe ECG</title>
	  <meta charset ="utf-8"/>
	  <link rel ="stylesheet" href="css/main.css" type="text/css"/>  
	  <link rel ="stylesheet" href="css/media-query.css" type="text/css"/> 
      <meta name= "viewport" content= "width=device-width, initial-scale=1.0">
</head>

<body>
<header>
		<nav class="zoom">
			<ul>
			    <li><a href="index.php">HOME</a></li>
				<li><a href="about.php">ABOUT</a></li>
				<li><a href="media.php">MEDIA</a></li>
				<li><a href="programs.php">PROGRAMS</a></li>
			</ul>
		
			  <div id="logo">
				<img src="imgs/logo.png"/>
				<h1>ENLIGHTENED CHRISTIAN GATHERING</h1>
			  </div>
			  
			<ul id="scnd-ul">
				
				<li id="test"><a href="https://www.youtube.com/user/propheticchannelTv">PROPHETIC TV</a></li>
				<li><a href="contacts.php">CONTACTS</a></li>
				<li><a href="sermons.php">SERMONS</a></li>
				<li><a href="events.php">EVENTS</a></li>
			</ul>
		</nav>
	
	
</header>


</body>


</html>