<!DOCTYPE html>


<html lang ="en">

<head>
      <title>Lilongwe ECG</title>
	  <meta charset ="utf-8"/>
	  <link rel ="stylesheet" href="css/main.css" type="text/css"/>  
	  <link rel ="stylesheet" href="css/media-query.css" type="text/css"/> 
      <meta name= "viewport" content= "width=device-width, initial-scale=1.0">
	    <script type="text/javascript">
	     if(screen.width <= 699){
			document.location = "m/contactsm.php";
		 }	
       </script>

</head>

<body>

<?php include 'header2.php';?>

<section id="back-serv">

<div class="background-wrap">
		  <video id="video-bg-elem" preload="auto" autoplay="true" loop="loop" muted="muted" class="vid">
			<source src="imgs/backg.mp4" type= "video/mp4">  
		  </video>
</div>


</section>





<div id="conta">

	 <h1 id="cont-h">CONTACT US</h1>
	 
	 <div id="top-man">
	   <h2>ECG CITY</h2>
		  <p id="brev">Area 47,Off Mchinji Road 
				from Petroda filling station 
				Next to Anglican Theological College
				opposite Dreamland
		  </p>
		  
			 <div id="smosh">
			   <img id ="one" src="imgs/man1.png"/>
			   <p id="kan">0888 963 220<br> 0994 860 773<br><br>Ecglilongwe@gmail.com</p>
			   <img id ="two" src="imgs/en1.png"/>	
			</div>
			 <img id ="loco" src="imgs/ran.png"/>
	 </div>
	 
	 <div id="form-man">
	 <form id="my_form">
		<input placeholder="First Name" type="text" id="fn1" required>
		<input placeholder="Last Name" type="text" id="ln1" required>
		<input placeholder="phone number" type="phone" id="p1" required>
		<input placeholder="Email" type="email" id="e1" required> <br/>
		<textarea id="txt"></textarea>
       <p><input id="mybtn" type="submit" value="Submit Form"> <span id="status"></span></p>
    </form>
	 </div>
	 
	 <div id="map">
	 
	   <img src="imgs/map.png"/>
	 
	 
	 
	 
	 </div>
	 <script>
	   function initMap() {
		   var location = {lat: -25.363, lng:131.044};
		   var map = new google.maps.Map(document.getElementById("map"), {
			   zoom:4,
			   center:location
		   });
		  var marker = new google.maps.Marker({
			  position: location,
			  map: map
		  });
		}
	 </script>
	 <script async defer src="https://maps.googleapis.com/maps/api/js?key=">
	 
	 
	 </script>
	
	 
	
	 
</div>


<div id="clear"></div>



<?php include 'footer.php';?>


</body>

</html>

