<!DOCTYPE html>


<html lang ="en">

<head>
	  <meta charset ="utf-8"/>
	  <link rel ="stylesheet" href="css/main.css" type="text/css"/>  
	  <link rel ="stylesheet" href="css/media-query.css" type="text/css"/> 
      <meta name= "viewport" content= "width=device-width, initial-scale=1.0">
</head>

<body>
<footer>
  <div id="quicklinks">
     <h3>Quick links</h3>
	 <p>About us</p>
	 <p>Media</p>
	 <p>Blog</p>
	 <p>Programs</p>
	 <p>Media</p>
	 <p>Contact</p>
	 <p>Prophetic Channel Tv</p>
	 <p>Sherpherd bushiri ministries</p>
  </div>
  
  <div id="cont">
     <h3>Connect with us</h3>
	 <img src="imgs/facebook.png"/>
	 <img src="imgs/twitter.png"/>
	 <p>Ecglilongwe@gmail.com</p>
  </div>
  
  <div id="loc">
     <img src="imgs/logo.png"/>
	 <p>More than a church, We are a family <br>Welcome to our visitors we know God<br> will meet your need in this<br> place of liberty</p>
  </div>
<div id="clear"></div>
<div id="copyright">

 <p>Copyright &copy; 2018,ECG Lilongwe.All Rights Reserved.</p>

</div>

</footer>


</body>


</html>