$(document).on('scroll',function(){
	  if($(this).scrollTop() > 1) {
		 $('nav').addClass('zoom');    
	  } else {
		  $('nav').removeClass('zoom');  
	  }
});


$('#btn').click(function() {
     $('#llz-frame').slideUp(1000);
	 $('#major-frame').slideDown(1000); 
	 $(this).css("padding","0.6rem").css("top","1.6rem").css("color","#fff");
     $('#btn2').css("padding","0.3rem").css("top","1.9rem").css("color","cyan");  	 
});


$('#btn2').click(function() {
     $('#llz-frame').slideDown(1000);
	 $('#major-frame').slideUp(1000); 
	 $(this).css("padding","0.6rem").css("top","1.6rem").css("color","#fff");
	 $('#btn').css("padding","0.3rem").css("top","1.9rem").css("color","cyan");
});


 /* var widith = window.innerWidth;
	var myHeight = window.innerHeight
    alert("your width is "+ widith+" and your height is "+myHeight);*/
  