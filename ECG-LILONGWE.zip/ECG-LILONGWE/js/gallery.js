
$('#zuma1').click(function() {
	$('#big-one').fadeOut().fadeIn(1000);
  $('#big-one').html($("<img src='imgs/1.jpg'>"));
  $('#photodesco').html('Major-one, Opening Prayer.');
});

$('#zuma2').click(function() {
	$('#big-one').fadeOut().fadeIn(1000);
  $('#big-one').html($("<img src='imgs/2.jpg'>"));
  $('#photodesco').html('Major-one, Preaching.');
});

$('#zuma3').click(function() {
	$('#big-one').fadeOut().fadeIn(1000);
  $('#big-one').html($("<img src='imgs/3.jpg'>"));
  $('#photodesco').html('Major-one, Preaching.');
});

$('#zuma4').click(function() {
	$('#big-one').fadeOut().fadeIn(1000);
  $('#big-one').html($("<img src='imgs/4.png'>"));
  $('#photodesco').html('Wise Man, Opening Prayer.');
});

$('#zuma5').click(function() {
	$('#big-one').fadeOut().fadeIn(1000);
  $('#big-one').html($("<img src='imgs/5.png'>"));
  $('#photodesco').html('Wise Man Trevour Preaching');
});

$('#zuma6').click(function() {
   $('#big-one').fadeOut().fadeIn(1000);
  $('#big-one').html($("<img src='imgs/6.png'>"));
  $('#photodesco').html('Wise Man Trevour Preaching');
});

$('#zuma7').click(function() {
  $('#big-one').fadeOut().fadeIn(1000);
  $('#big-one').html($("<img src='imgs/7.png'>"));
  $('#photodesco').html('Congregation in worship');
});

$('#zuma8').click(function() {
	$('#big-one').fadeOut().fadeIn(1000);
  $('#big-one').html($("<img src='imgs/8.png'>"));
  $('#photodesco').html('Congregation in worship');
});

$('#zuma9').click(function() {
	$('#big-one').fadeOut().fadeIn(1000);
  $('#big-one').html($("<img src='imgs/9.jpg'>"));
  $('#photodesco').html('Congregation in worship');
});

$('#zuma10').click(function() {
	$('#big-one').fadeOut().fadeIn(1000);
  $('#big-one').html($("<img src='imgs/10.jpg'>"));
  $('#photodesco').html('Major in Worship');
});

$('#zuma11').click(function() {
	$('#big-one').fadeOut().fadeIn(1000);
  $('#big-one').html($("<img src='imgs/11.png'>"));
  $('#photodesco').html('Wise Man Trevour Worshipping');
});

$('#zuma12').click(function() {
	$('#big-one').fadeOut().fadeIn(1000);
  $('#big-one').html($("<img src='imgs/12.jpg'>"));
  $('#photodesco').html('Preach');
});









