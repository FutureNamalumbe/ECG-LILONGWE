$('#lochom').click(function() {
   $('#contentloc').slideToggle(1000);
});







