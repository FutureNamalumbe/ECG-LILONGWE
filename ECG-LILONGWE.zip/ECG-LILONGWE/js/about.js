$('#major-cont').click(function() {
   $('#about-info').html($("<h2 id='proid'>PROPHET SHERPHERD BUSHIRI</h2>"));
   $('#about-info').append("<P id='bno'>Prophet Shepherd Bushiri is the founder of Enlightened Christian Gathering Church (ECG)  and the Shepherd Bushiri Ministries International. ECG Church has its head quarters in Pretoria the capital city of South Africa and branches across the African continent. Prophet Shepherd Bushiri is mightily used by God in prophetic, healing and deliverance ministries. His ministry is also known as the ministry of the book of Acts because of the great undeniable signs and wonders which happen in the name of Jesus. His prophecies are accurate and precise </P>");
   $('#about-info').append($("<p> His award-winning Prophetic Channel television broadcast reaches millions of homes across the globe. Touching the lives of many and inspiring them to live a life that is holy and acceptable unto God. A much sought-after motivational speaker to young and old, Prophet Shepherd Bushiri is known for his prophetic capabilities to speak the Word of the Lord with accuracy and precision, and has encouraged millions to pursue a personal relationship with God by hearkening to the voice of the Lord.</p>"));
   $('#about-img').html($("<img src='imgs/major.jpg' class='big'>"));
});

$('#ecg-cont').click(function() {
   $('#about-info').html($("<h2>ABOUT ECG</h2>"));
   $('#about-info').append("<P>Enlightened Christian Gathering Church is a modern congregation of Christ–centered believers celebrating God through the Prophetic, Healing and Deliverance Ministries. It is home to millions across the globe who seek to hear God speaking today.ECG is led by founder and leader Major Prophet Shepherd Bushiri. ECG is more than a church, it is a family, where every race and class is accommodated , where the DNA of God declares each of us as citizens of heaven, lives are transformed and miracles and testimonies are the order of the day as demons and challenges are confronted and conquered; in our family we don’t stress!. </P>");
   $('#about-info').append($("<br>"));
   $('#about-info').append($("<p>At ECG we are a friendly and happy family made up of people from all walks of life, and different backgrounds who are united through love of christ. we believe in transforming power of jesus christ and bringing down the kingdom of God. This power we believe changes lives, brings healing to the sick, deliverance to the tormented, happines and joy to the weary and frustrated. We invite you to experience this changing power and love, and we promise you. </p>")).append("<span id='same'>YOU WILL NEVER BE THE SAME</span>");
   $('#about-img').html($("<img src='imgs/cow.jpg' class='big'>")); 
  
});

